//
alert("background script is running");

// chrome.browserAction.onClicked.addListener(function(tab) {
//    chrome.tabs.executeScript(null, {file: "content.js"});
// });

chrome.identity.getAuthToken({
    interactive: true
}, function(token) {
    if (chrome.runtime.lastError) {
        alert(chrome.runtime.lastError.message);
        alert("a error");

        console.log("a");
        return;
    }
    var x = new XMLHttpRequest();
    x.open('GET', 'https://www.googleapis.com/oauth2/v2/userinfo?alt=json&access_token=' + token);
    x.onload = function() {
        alert(x.response);
    };
    x.send();
});

// chrome.identity.getProfileUserInfo(function(userInfo) {
//  /* Use userInfo.email, or better (for privacy) userInfo.id
//     They will be empty if user is not signed in in Chrome */
//     alert(userInfo.email)
//     alert(userInfo.id)
// });



// chrome.cookies.get({url:'https://accounts.google.com', name:'LSID'}, function(cookie) {
//     if (cookie) {
//         alert('Sign-in cookie:', cookie);
//     }
//     else {
//       alert("no cookie")
//     }
// });

alert("script end");
